from whylogs.api.store.profile_store import ProfileStore


class S3Store(ProfileStore):
    pass
