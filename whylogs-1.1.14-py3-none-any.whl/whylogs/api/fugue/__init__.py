# flake8: noqa
from .profiler import fugue_profile
