from whylogs.datasets.ecommerce import Ecommerce
from whylogs.datasets.weather import Weather

__ALL__ = [
    # column
    Weather,
    Ecommerce,
]
