from whylogs.viz.extensions.reports.html_report import HTMLReport


class ConstraintsReport(HTMLReport):
    pass
